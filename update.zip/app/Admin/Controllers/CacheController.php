<?php

namespace App\Admin\Controllers;

use App\Admin\Forms\Cache;
use App\Http\Controllers\Controller;
use Encore\Admin\Layout\Content;
use Encore\Admin\Widgets\Tab;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class CacheController extends Controller
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title;

    public function __construct()
    {
        $this->title = lp("Cache", 'Setting');
    }
    
    public function index(Content $content)
    {
        $form = [
            'cache' => Cache::class,
        ];

        return $content
            ->title(lp("Cache", 'Setting'))
            ->body(Tab::forms($form));
    }

    /**
     * 清空换缓存
     *
     * @param Request $request
     * @return void
     */
    public function clear(Request $request)
    {
        $categoryId = $request->input('category_id');
        $type = $request->input('type', 'index');

        $path = 'cache/templates/'.$categoryId.'/'.$type;
        if (Storage::disk('local')->files($path)) {
            Storage::disk('local')->deleteDirectory($path);
        }

        return json_encode([
            'code' => 0,
            'message' => '清空成功'
        ]);
    }
}
