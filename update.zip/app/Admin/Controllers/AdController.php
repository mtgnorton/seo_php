<?php

namespace App\Admin\Controllers;

use App\Admin\Forms\Ad;
use App\Http\Controllers\Controller;
use Encore\Admin\Layout\Content;
use Encore\Admin\Widgets\Tab;

class AdController extends Controller
{
    /**
     * Title for current resource.
     *
     * @var string
     */
    protected $title;

    public function __construct()
    {
        $this->title = lp("Ad", 'Setting');
    }
    
    public function index(Content $content)
    {
        $form = [
            'ad' => Ad::class,
        ];

        return $content
            ->title(lp("Ad", 'Setting'))
            ->body(Tab::forms($form));
    }
}
