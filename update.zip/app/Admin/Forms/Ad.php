<?php

namespace App\Admin\Forms;

use App\Models\Category;
use App\Models\Config;
use Encore\Admin\Widgets\Form;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class Ad extends Base
{
    public function tabTitle()
    {
        return lp('Ad', 'Config');
    }

    /**
     * Build a form here.
     */
    public function form()
    {
        $categoryId = request()->input('category_id');
        $this->hidden('category_id')->default($categoryId);
        $states = [
            'on'  => ['value' => 'on', 'text' => '开启', 'color' => 'success'],
            'off' => ['value' => 'off', 'text' => '关闭', 'color' => 'danger'],
        ];
        $this->switch('is_open', lp('Is open', 'Ad'))->states($states);
        $this->textarea('urls', ll('Url'))->help(ll('Spider url help'));
        $this->radio('type', lp('Ad', 'Type'))->options([
            'system' => ll('System'),
            'diy' => ll('Diy')
        ])->default('system');
        // $this->radio('position', ll('Position'))->options([
        //     'header' => ll('Header'),
        //     'footer' => ll('Footer')
        // ])->default('footer');
        $this->textarea('diy_content', lp('Diy', 'Content'))
            ->help(ll('Ad diy content help'));
    }

    /**
     * Handle the form request.
     *
     * @param Request $request
     *
     * @return \Illuminate\Http\RedirectResponse
     */
    public function handle(Request $request)
    {
        $data = $request->except('category_id');
        $categoryId = $request->input('category_id');

        // 将广告内容写入文件
        $category = Category::find($categoryId);
        $path = 'ad/'.$category->tag . '.html';
        Storage::disk('public')->put($path, $data['diy_content']);

        collect($data)->map(function ($v, $k) use ($categoryId) {
            Config::updateOrCreate([
                'module' => $this->getModule(),
                'category_id' => $categoryId,
                'key' => $k
            ], [
                'value' => $v
            ]);
        });

        admin_success(ll('Update success'));

        return back();
    }

    /**
     * The data of the form.
     *
     * @return array $data
     */
    public function data()
    {
        $categoryId = request()->input('category_id');

        return Config::where([
            'module' => $this->getModule(),
            'category_id' => $categoryId
        ])->pluck('value', 'key');
    }
}
